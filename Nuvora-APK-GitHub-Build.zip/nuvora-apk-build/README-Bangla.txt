NUVORA APK BUILD

এই ZIP Nuvora-এর বর্তমান web app-কে GitHub Actions দিয়ে Android APK বানানোর জন্য প্রস্তুত করা হয়েছে।

GitHub-এ ব্যবহার:
1. Nuvora-এর GitHub repository খুলুন।
2. এই ZIP-এর ভেতরের সব ফাইল repository root-এ আপলোড করুন।
3. www/index.html বর্তমান Nuvora index.html-এর APK build copy হিসেবে থাকবে।
4. .github/workflows/build-apk.yml অবশ্যই ওই একই path-এ থাকতে হবে।
5. Commit করুন।
6. GitHub > Actions > Build Nuvora APK খুলুন।
7. সফল হলে Nuvora-APK নামে Artifact পাবেন।
8. Artifact download করে ZIP খুলে app-debug.apk ফোনে Install করুন।

নোট:
- এটি debug APK, তাই ব্যক্তিগতভাবে ফোনে পরীক্ষা/ব্যবহারের জন্য।
- Play Store-এর জন্য পরে signed release/AAB আলাদা করে করা যাবে।
- Nuvora backend Worker/D1 এই APK-এর ভেতরে থাকে না; app একই API URL ব্যবহার করে।
