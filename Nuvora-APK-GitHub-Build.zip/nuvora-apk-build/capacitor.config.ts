import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.nuvora.app',
  appName: 'Nuvora',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
