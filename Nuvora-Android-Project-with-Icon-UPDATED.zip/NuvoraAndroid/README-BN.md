# Nuvora Android APK Project

এই প্রজেক্টটি Nuvora-এর বর্তমান `index.html`-কে Android WebView app হিসেবে প্যাকেজ করার জন্য প্রস্তুত করা হয়েছে।

## Android Studio দিয়ে APK বানানো
1. Android Studio খুলুন।
2. এই `NuvoraAndroid` folder-টি Open করুন।
3. Gradle Sync শেষ হতে দিন।
4. `Build > Build APK(s)` নির্বাচন করুন।
5. Debug APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ তৈরি হবে।

## গুরুত্বপূর্ণ
- App-এর API endpoint বর্তমান HTML-এর মধ্যে `https://nuvora-api.allaccess320.workers.dev` হিসেবে সেট করা আছে।
- তাই APK-এর জন্য Internet permission রাখা হয়েছে।
- বর্তমান HTML-এর Login, account creation, private messaging, posts এবং Gather/group UI একইভাবে রাখা হয়েছে।
- Release APK প্রকাশের আগে নিজের signing key দিয়ে signed build করা উচিত।
